# StreamHub MVP

A legal streaming-discovery MVP for Android. It does **not** stream, copy or bypass DRM-protected video. Provider buttons open official provider URLs/apps when Android can route them.

## Included
- Dark streaming-style home screen
- Search by title/genre
- Movie/TV detail screen
- Local in-memory watchlist for this MVP
- Provider launch buttons
- Netflix / Prime Video / Disney+ / Crunchyroll provider support structure
- GitHub Actions workflow that builds an installable debug APK

## Build locally
Open this folder in a current Android Studio installation and run the `app` configuration.

## Build an APK on GitHub for free
1. Create a new GitHub repository.
2. Upload the **contents** of this folder to the repository root.
3. Open **Actions** > **Build Android APK** > **Run workflow**.
4. When the workflow completes, open the run and download the `StreamHub-MVP-debug` artifact.
5. Extract it to get `app-debug.apk`, then install that APK on your Android phone.

You may need to allow “Install unknown apps” for the browser/files app you use to open the APK.

## Important MVP limitation
The catalogue and availability entries in this build are demo data. A commercial release needs a properly licensed/current metadata and streaming-availability source.
